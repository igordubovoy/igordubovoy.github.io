shopApp.directive('buttons', function () {
  return {
    restrict: 'E',
    templateUrl: 'nav-buttons/buttons.html'
  }
});
