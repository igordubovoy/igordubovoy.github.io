shopApp.directive('productsshopcart', function () {
  return {
    restrict: 'E',
    templateUrl: 'products/products-shop-cart.html'
  }
});
