shopApp.directive('products', function () {
  return {
    restrict: 'E',
    templateUrl: 'products/products.html'
  }
});
