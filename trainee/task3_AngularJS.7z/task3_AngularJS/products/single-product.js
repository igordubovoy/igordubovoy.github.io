shopApp.directive('product', function () {
  return {
    restrict: 'E',
    templateUrl: 'products/single-product.html'
  }
});
