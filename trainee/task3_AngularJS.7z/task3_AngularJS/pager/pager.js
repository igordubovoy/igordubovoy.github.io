shopApp.directive('pager', function () {
  return {
    restrict: 'E',
    templateUrl: 'pager/pager.html'
  }
});
