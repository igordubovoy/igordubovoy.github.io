shopApp.directive('sortingmenu', function () {
  return {
    restrict: 'E',
    templateUrl: 'sort-menu/sorting-menu.html'
  }
});
